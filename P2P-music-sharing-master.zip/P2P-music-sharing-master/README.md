# P2P-music-sharing
This is a networking project where i make a peer to peer network to share files among peers

The application is developed using python3 

To run the code run the command 
python3 p2p.py 
